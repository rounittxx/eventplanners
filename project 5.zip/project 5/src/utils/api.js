
const moviesData = [
  {
    id: '1',
    title: 'The Last Adventure',
    genre: 'Action/Adventure',
    duration: '2h 15m',
    rating: '8.5',
    language: 'English',
    releaseDate: '2025-02-15',
    director: 'Christopher Smith',
    cast: ['John Miller', 'Sarah Davis', 'Michael Chen'],
    description: 'A thrilling adventure through uncharted territories as a team of explorers face the ultimate challenge of survival.',
    posterUrl: 'https://images.pexels.com/photos/2873486/pexels-photo-2873486.jpeg?auto=compress&cs=tinysrgb&w=600',
    trailerUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    showTimes: [
      { id: 'st1', time: '10:00 AM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st2', time: '1:30 PM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st3', time: '4:45 PM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st4', time: '8:00 PM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st5', time: '11:30 AM', theater: 'Starlight Movies', date: '2025-04-20' },
      { id: 'st6', time: '3:15 PM', theater: 'Starlight Movies', date: '2025-04-20' },
      { id: 'st7', time: '7:30 PM', theater: 'Starlight Movies', date: '2025-04-20' },
    ]
  },
  {
    id: '2',
    title: 'City Nights',
    genre: 'Drama/Crime',
    duration: '2h 30m',
    rating: '9.0',
    language: 'English',
    releaseDate: '2025-03-10',
    director: 'Elena Rodriguez',
    cast: ['Robert Johnson', 'Lisa Wong', 'David Martinez'],
    description: 'In the shadows of the city, a detective uncovers a conspiracy that goes deeper than anyone could have imagined.',
    posterUrl: 'https://images.pexels.com/photos/3131971/pexels-photo-3131971.jpeg?auto=compress&cs=tinysrgb&w=600',
    trailerUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    showTimes: [
      { id: 'st8', time: '11:00 AM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st9', time: '2:30 PM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st10', time: '5:45 PM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st11', time: '9:00 PM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st12', time: '12:30 PM', theater: 'Starlight Movies', date: '2025-04-20' },
      { id: 'st13', time: '4:15 PM', theater: 'Starlight Movies', date: '2025-04-20' },
      { id: 'st14', time: '8:30 PM', theater: 'Starlight Movies', date: '2025-04-20' },
    ]
  },
  {
    id: '3',
    title: 'The Laugh Factory',
    genre: 'Comedy',
    duration: '1h 45m',
    rating: '7.8',
    language: 'English',
    releaseDate: '2025-01-25',
    director: 'James Wilson',
    cast: ['Emma Thompson', 'Mark Lee', 'Jennifer Smith'],
    description: 'When a failing comedy club gets a new owner, the staff must adapt to his outrageous methods or find themselves out of a job.',
    posterUrl: 'https://images.pexels.com/photos/1174170/pexels-photo-1174170.jpeg?auto=compress&cs=tinysrgb&w=600',
    trailerUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    showTimes: [
      { id: 'st15', time: '10:30 AM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st16', time: '1:00 PM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st17', time: '3:45 PM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st18', time: '6:15 PM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st19', time: '9:30 PM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st20', time: '12:00 PM', theater: 'Starlight Movies', date: '2025-04-20' },
      { id: 'st21', time: '4:45 PM', theater: 'Starlight Movies', date: '2025-04-20' },
    ]
  },
  {
    id: '4',
    title: 'Eternal Love',
    genre: 'Romance/Drama',
    duration: '2h 10m',
    rating: '8.2',
    language: 'English',
    releaseDate: '2025-02-14',
    director: 'Sophie Chen',
    cast: ['Daniel Parker', 'Olivia White', 'Thomas Brown'],
    description: 'A timeless love story that spans decades, showing how true love can overcome the greatest obstacles.',
    posterUrl: 'https://images.pexels.com/photos/1571673/pexels-photo-1571673.jpeg?auto=compress&cs=tinysrgb&w=600',
    trailerUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    showTimes: [
      { id: 'st22', time: '11:15 AM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st23', time: '2:00 PM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st24', time: '5:30 PM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st25', time: '8:45 PM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st26', time: '1:15 PM', theater: 'Starlight Movies', date: '2025-04-20' },
      { id: 'st27', time: '6:00 PM', theater: 'Starlight Movies', date: '2025-04-20' },
      { id: 'st28', time: '9:15 PM', theater: 'Starlight Movies', date: '2025-04-20' },
    ]
  },
  {
    id: '5',
    title: 'Space Odyssey',
    genre: 'Sci-Fi/Adventure',
    duration: '2h 25m',
    rating: '8.7',
    language: 'English',
    releaseDate: '2025-03-20',
    director: 'Andrew Kim',
    cast: ['Michelle Davis', 'Richard Wilson', 'Samantha Lee'],
    description: 'A journey to the farthest reaches of the galaxy reveals secrets about humanity\'s origins and future.',
    posterUrl: 'https://images.pexels.com/photos/1509534/pexels-photo-1509534.jpeg?auto=compress&cs=tinysrgb&w=600',
    trailerUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    showTimes: [
      { id: 'st29', time: '10:45 AM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st30', time: '1:45 PM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st31', time: '5:00 PM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st32', time: '8:30 PM', theater: 'Cinema Plaza', date: '2025-04-20' },
      { id: 'st33', time: '11:45 AM', theater: 'Starlight Movies', date: '2025-04-20' },
      { id: 'st34', time: '3:30 PM', theater: 'Starlight Movies', date: '2025-04-20' },
      { id: 'st35', time: '7:00 PM', theater: 'Starlight Movies', date: '2025-04-20' },
      { id: 'st36', time: '10:15 PM', theater: 'Starlight Movies', date: '2025-04-20' },
    ]
  }
];


const eventsData = [
  {
    id: 'e1',
    title: 'Summer Music Festival',
    category: 'Concerts',
    date: '2025-06-15',
    time: '2:00 PM',
    venue: 'Central Park Amphitheater',
    city: 'New York',
    price: 75,
    description: 'A full day of amazing live performances from top artists across multiple genres.',
    imageUrl: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=600',
    artists: ['Band A', 'Singer B', 'Group C']
  },
  {
    id: 'e2',
    title: 'Shakespeare in the Park',
    category: 'Theater',
    date: '2025-05-20',
    time: '7:30 PM',
    venue: 'City Botanical Gardens',
    city: 'Los Angeles',
    price: 40,
    description: 'A magical outdoor performance of "A Midsummer Night\'s Dream" under the stars.',
    imageUrl: 'https://images.pexels.com/photos/713149/pexels-photo-713149.jpeg?auto=compress&cs=tinysrgb&w=600',
    artists: ['City Theater Company']
  },
  {
    id: 'e3',
    title: 'Tech Innovation Expo',
    category: 'Exhibition',
    date: '2025-07-05',
    time: '10:00 AM',
    venue: 'Metro Convention Center',
    city: 'San Francisco',
    price: 25,
    description: 'Explore the latest in technology innovations and meet industry leaders.',
    imageUrl: 'https://images.pexels.com/photos/2566581/pexels-photo-2566581.jpeg?auto=compress&cs=tinysrgb&w=600',
    exhibitors: ['Tech Company A', 'Startup B', 'Innovation Lab C']
  },
  {
    id: 'e4',
    title: 'Championship Basketball',
    category: 'Sports',
    date: '2025-05-25',
    time: '8:00 PM',
    venue: 'National Arena',
    city: 'Chicago',
    price: 60,
    description: 'The exciting final game of the season to determine this year\'s champions.',
    imageUrl: 'https://images.pexels.com/photos/3755440/pexels-photo-3755440.jpeg?auto=compress&cs=tinysrgb&w=600',
    teams: ['Eagles', 'Lions']
  },
  {
    id: 'e5',
    title: 'Food & Wine Festival',
    category: 'Food',
    date: '2025-06-10',
    time: '12:00 PM',
    venue: 'Riverside Park',
    city: 'Miami',
    price: 50,
    description: 'Sample delicious creations from top chefs and wineries in this culinary extravaganza.',
    imageUrl: 'https://images.pexels.com/photos/3184183/pexels-photo-3184183.jpeg?auto=compress&cs=tinysrgb&w=600',
    participants: ['Chef A', 'Restaurant B', 'Winery C']
  }
];


const seatLayoutData = {
  rows: [
    { id: 'A', seats: [
      { id: 'A1', type: 'regular', price: 12, status: 'available' },
      { id: 'A2', type: 'regular', price: 12, status: 'available' },
      { id: 'A3', type: 'regular', price: 12, status: 'booked' },
      { id: 'A4', type: 'regular', price: 12, status: 'booked' },
      { id: 'A5', type: 'regular', price: 12, status: 'available' },
      { id: 'A6', type: 'regular', price: 12, status: 'available' },
      { id: 'A7', type: 'regular', price: 12, status: 'available' },
      { id: 'A8', type: 'regular', price: 12, status: 'available' }
    ]},
    { id: 'B', seats: [
      { id: 'B1', type: 'regular', price: 12, status: 'available' },
      { id: 'B2', type: 'regular', price: 12, status: 'available' },
      { id: 'B3', type: 'regular', price: 12, status: 'available' },
      { id: 'B4', type: 'regular', price: 12, status: 'available' },
      { id: 'B5', type: 'regular', price: 12, status: 'available' },
      { id: 'B6', type: 'regular', price: 12, status: 'booked' },
      { id: 'B7', type: 'regular', price: 12, status: 'booked' },
      { id: 'B8', type: 'regular', price: 12, status: 'available' }
    ]},
    { id: 'C', seats: [
      { id: 'C1', type: 'regular', price: 12, status: 'available' },
      { id: 'C2', type: 'regular', price: 12, status: 'booked' },
      { id: 'C3', type: 'regular', price: 12, status: 'booked' },
      { id: 'C4', type: 'regular', price: 12, status: 'available' },
      { id: 'C5', type: 'regular', price: 12, status: 'available' },
      { id: 'C6', type: 'regular', price: 12, status: 'available' },
      { id: 'C7', type: 'regular', price: 12, status: 'available' },
      { id: 'C8', type: 'regular', price: 12, status: 'available' }
    ]},
    { id: 'D', seats: [
      { id: 'D1', type: 'premium', price: 15, status: 'available' },
      { id: 'D2', type: 'premium', price: 15, status: 'available' },
      { id: 'D3', type: 'premium', price: 15, status: 'available' },
      { id: 'D4', type: 'premium', price: 15, status: 'available' },
      { id: 'D5', type: 'premium', price: 15, status: 'available' },
      { id: 'D6', type: 'premium', price: 15, status: 'available' },
      { id: 'D7', type: 'premium', price: 15, status: 'available' },
      { id: 'D8', type: 'premium', price: 15, status: 'available' }
    ]},
    { id: 'E', seats: [
      { id: 'E1', type: 'premium', price: 15, status: 'booked' },
      { id: 'E2', type: 'premium', price: 15, status: 'booked' },
      { id: 'E3', type: 'premium', price: 15, status: 'available' },
      { id: 'E4', type: 'premium', price: 15, status: 'available' },
      { id: 'E5', type: 'premium', price: 15, status: 'available' },
      { id: 'E6', type: 'premium', price: 15, status: 'available' },
      { id: 'E7', type: 'premium', price: 15, status: 'booked' },
      { id: 'E8', type: 'premium', price: 15, status: 'booked' }
    ]},
    { id: 'F', seats: [
      { id: 'F1', type: 'vip', price: 20, status: 'available' },
      { id: 'F2', type: 'vip', price: 20, status: 'available' },
      { id: 'F3', type: 'vip', price: 20, status: 'available' },
      { id: 'F4', type: 'vip', price: 20, status: 'available' },
      { id: 'F5', type: 'vip', price: 20, status: 'available' },
      { id: 'F6', type: 'vip', price: 20, status: 'available' },
      { id: 'F7', type: 'vip', price: 20, status: 'available' },
      { id: 'F8', type: 'vip', price: 20, status: 'available' }
    ]}
  ],
  screen: 'front',
  legend: [
    { type: 'available', label: 'Available' },
    { type: 'booked', label: 'Booked' },
    { type: 'selected', label: 'Selected' }
  ]
};


const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));


export const fetchMovies = async () => {

  await delay(800);
  return moviesData;
};


export const fetchMovieById = async (id) => {

  await delay(600);
  const movie = moviesData.find(movie => movie.id === id);
  
  if (!movie) {
    throw new Error('Movie not found');
  }
  
  return movie;
};


export const fetchEvents = async () => {

  await delay(800);
  return eventsData;
};


export const fetchEventById = async (id) => {

  await delay(600);
  const event = eventsData.find(event => event.id === id);
  
  if (!event) {
    throw new Error('Event not found');
  }
  
  return event;
};

export const fetchSeats = async (movieId, showtimeId) => {

  await delay(1000);

  return seatLayoutData;
};


export const bookSeats = async (bookingData) => {

  await delay(1500);
  

  return {
    bookingId: 'bk' + Math.floor(Math.random() * 10000),
    status: 'confirmed',
    message: 'Booking successful',
    ...bookingData
  };
};


export const searchMovies = async (query) => {

  await delay(600);
  

  if (!query) return moviesData;
  
  const lowerQuery = query.toLowerCase();
  return moviesData.filter(movie => 
    movie.title.toLowerCase().includes(lowerQuery) ||
    movie.genre.toLowerCase().includes(lowerQuery) ||
    movie.cast.some(actor => actor.toLowerCase().includes(lowerQuery))
  );
};


export const filterMovies = async (filters) => {

  await delay(800);
  
  let filteredMovies = [...moviesData];
  
  if (filters.genre) {
    filteredMovies = filteredMovies.filter(movie => 
      movie.genre.toLowerCase().includes(filters.genre.toLowerCase())
    );
  }
  
  if (filters.language) {
    filteredMovies = filteredMovies.filter(movie => 
      movie.language.toLowerCase() === filters.language.toLowerCase()
    );
  }
  

  
  return filteredMovies;
};
import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { fetchMovieById } from '../utils/api'
import '../styles/MovieDetail.css'

function MovieDetail() {
  const { id } = useParams()
  const [movie, setMovie] = useState(null)
  const [loading, setLoading] = useState(true)
  const [selectedDate, setSelectedDate] = useState(null)
  const [selectedTheater, setSelectedTheater] = useState(null)
  
  useEffect(() => {
    const loadMovie = async () => {
      try {
        const data = await fetchMovieById(id)
        setMovie(data)
        

        if (data.showTimes && data.showTimes.length > 0) {
          setSelectedDate(data.showTimes[0].date)
          
      
          const theaters = [...new Set(
            data.showTimes
              .filter(st => st.date === data.showTimes[0].date)
              .map(st => st.theater)
          )]
          
          if (theaters.length > 0) {
            setSelectedTheater(theaters[0])
          }
        }
        
        setLoading(false)
      } catch (error) {
        console.error('Error loading movie:', error)
        setLoading(false)
      }
    }
    
    loadMovie()
  }, [id])
  
  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading movie details...</p>
      </div>
    )
  }
  
  if (!movie) {
    return (
      <div className="container">
        <div className="error-message">
          <h2>Movie Not Found</h2>
          <p>The movie you are looking for does not exist.</p>
          <Link to="/movies" className="btn btn-primary">Browse Movies</Link>
        </div>
      </div>
    )
  }
  
  
  const dates = [...new Set(movie.showTimes.map(st => st.date))]
  

  const theaters = [...new Set(
    movie.showTimes
      .filter(st => st.date === selectedDate)
      .map(st => st.theater)
  )]
  

  const filteredShowtimes = movie.showTimes.filter(
    st => st.date === selectedDate && st.theater === selectedTheater
  )
  
  return (
    <div className="movie-detail-page">
      <div className="movie-header" style={{ backgroundImage: `url(${movie.posterUrl})` }}>
        <div className="movie-header-overlay"></div>
        <div className="container">
          <div className="movie-header-content">
            <div className="movie-poster-container">
              <img src={movie.posterUrl} alt={movie.title} className="movie-poster" />
            </div>
            <div className="movie-info-container">
              <h1>{movie.title}</h1>
              <div className="movie-meta">
                <span className="movie-rating">{movie.rating}</span>
                <span className="movie-genre">{movie.genre}</span>
                <span className="movie-duration">{movie.duration}</span>
                <span className="movie-language">{movie.language}</span>
                <span className="movie-release">Released: {movie.releaseDate}</span>
              </div>
              <p className="movie-description">{movie.description}</p>
              <div className="movie-crew">
                <div className="crew-item">
                  <span className="crew-label">Director:</span>
                  <span className="crew-value">{movie.director}</span>
                </div>
                <div className="crew-item">
                  <span className="crew-label">Cast:</span>
                  <span className="crew-value">{movie.cast.join(', ')}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="container">
        <section className="movie-trailer-section">
          <h2>Trailer</h2>
          <div className="trailer-container">
            <iframe 
              src={movie.trailerUrl} 
              title={`${movie.title} Trailer`}
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
          </div>
        </section>
        
        <section className="showtimes-section">
          <h2>Showtimes</h2>
          
          <div className="showtimes-container">
            <div className="date-selector">
              <h3>Select Date</h3>
              <div className="date-pills">
                {dates.map(date => (
                  <button 
                    key={date}
                    className={`date-pill ${date === selectedDate ? 'active' : ''}`}
                    onClick={() => {
                      setSelectedDate(date)
               
                      const theatersForDate = [...new Set(
                        movie.showTimes
                          .filter(st => st.date === date)
                          .map(st => st.theater)
                      )]
                      if (theatersForDate.length > 0) {
                        setSelectedTheater(theatersForDate[0])
                      }
                    }}
                  >
                    {new Date(date).toLocaleDateString('en-US', { 
                      weekday: 'short', 
                      month: 'short', 
                      day: 'numeric' 
                    })}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="theater-selector">
              <h3>Select Theater</h3>
              <div className="theater-pills">
                {theaters.map(theater => (
                  <button 
                    key={theater}
                    className={`theater-pill ${theater === selectedTheater ? 'active' : ''}`}
                    onClick={() => setSelectedTheater(theater)}
                  >
                    {theater}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="time-selector">
              <h3>Select Showtime</h3>
              <div className="time-pills">
                {filteredShowtimes.map(showtime => (
                  <Link 
                    key={showtime.id}
                    to={`/select-seats/${movie.id}/${showtime.id}`}
                    className="time-pill"
                  >
                    {showtime.time}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}

export default MovieDetail
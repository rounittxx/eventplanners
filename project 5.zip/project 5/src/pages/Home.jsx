import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import Slider from 'react-slick'
import MovieCard from '../components/MovieCard'
import LocationSelector from '../components/LocationSelector'
import { fetchMovies, fetchEvents } from '../utils/api'
import "slick-carousel/slick/slick.css"
import "slick-carousel/slick/slick-theme.css"
import '../styles/Home.css'

function Home() {
  const [movies, setMovies] = useState([])
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(true)
  
  useEffect(() => {
    const loadData = async () => {
      try {
        const moviesData = await fetchMovies()
        const eventsData = await fetchEvents()
        
        setMovies(moviesData)
        setEvents(eventsData)
        setLoading(false)
      } catch (error) {
        console.error('Error loading data:', error)
        setLoading(false)
      }
    }
    
    loadData()
  }, [])
  
  const carouselSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
    arrows: true,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          arrows: false
        }
      }
    ]
  }
  
  const movieCarouselSettings = {
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          arrows: false
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1.5,
          arrows: false,
          centerMode: true,
          centerPadding: '40px'
        }
      }
    ]
  }
  
  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading amazing content...</p>
      </div>
    )
  }
  
  return (
    <div className="home-page">
      <section className="hero-section">
        <Slider {...carouselSettings} className="hero-carousel">
          <div className="carousel-item">
            <div className="carousel-content" style={{ backgroundImage: `url(https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg)` }}>
              <div className="carousel-overlay"></div>
              <div className="carousel-text">
                <h1>Latest Blockbusters</h1>
                <p>Experience the magic of cinema with the latest releases</p>
                <Link to="/movies" className="btn btn-primary">Book Now</Link>
              </div>
            </div>
          </div>
          <div className="carousel-item">
            <div className="carousel-content" style={{ backgroundImage: `url(https://images.pexels.com/photos/2263436/pexels-photo-2263436.jpeg)` }}>
              <div className="carousel-overlay"></div>
              <div className="carousel-text">
                <h1>Live Concerts</h1>
                <p>Feel the rhythm and energy of live performances</p>
                <Link to="/events?category=concerts" className="btn btn-primary">Explore Events</Link>
              </div>
            </div>
          </div>
          <div className="carousel-item">
            <div className="carousel-content" style={{ backgroundImage: `url(https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg)` }}>
              <div className="carousel-overlay"></div>
              <div className="carousel-text">
                <h1>Exclusive Deals</h1>
                <p>Special discounts and offers on selected movies and events</p>
                <Link to="/offers" className="btn btn-primary">View Offers</Link>
              </div>
            </div>
          </div>
        </Slider>
      </section>
      
      <div className="container">
        <section className="location-section">
          <LocationSelector />
        </section>
        
        <section className="trending-section">
          <div className="section-header">
            <h2>Trending Movies</h2>
            <Link to="/movies" className="view-all">View All</Link>
          </div>
          
          <Slider {...movieCarouselSettings} className="movie-carousel">
            {movies.map(movie => (
              <div key={movie.id} className="movie-carousel-item">
                <MovieCard movie={movie} />
              </div>
            ))}
          </Slider>
        </section>
        
        <section className="category-section">
          <div className="section-header">
            <h2>Browse by Category</h2>
          </div>
          
          <div className="category-grid">
            <Link to="/movies?genre=action" className="category-card" style={{ backgroundImage: `url(https://images.pexels.com/photos/2833037/pexels-photo-2833037.jpeg)` }}>
              <div className="category-overlay"></div>
              <span>Action</span>
            </Link>
            <Link to="/movies?genre=comedy" className="category-card" style={{ backgroundImage: `url(https://images.pexels.com/photos/7991140/pexels-photo-7991140.jpeg)` }}>
              <div className="category-overlay"></div>
              <span>Comedy</span>
            </Link>
            <Link to="/movies?genre=drama" className="category-card" style={{ backgroundImage: `url(https://images.pexels.com/photos/3532542/pexels-photo-3532542.jpeg)` }}>
              <div className="category-overlay"></div>
              <span>Drama</span>
            </Link>
            <Link to="/events?category=concerts" className="category-card" style={{ backgroundImage: `url(https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg)` }}>
              <div className="category-overlay"></div>
              <span>Concerts</span>
            </Link>
          </div>
        </section>
        
        <section className="events-section">
          <div className="section-header">
            <h2>Upcoming Events</h2>
            <Link to="/events" className="view-all">View All</Link>
          </div>
          
          <div className="events-grid">
            {events.slice(0, 3).map(event => (
              <div key={event.id} className="event-card">
                <div className="event-image" style={{ backgroundImage: `url(${event.imageUrl})` }}></div>
                <div className="event-card-content">
                  <div className="event-date">
                    <span className="day">{new Date(event.date).getDate()}</span>
                    <span className="month">{new Date(event.date).toLocaleString('default', { month: 'short' })}</span>
                  </div>
                  <h3>{event.title}</h3>
                  <p className="event-venue">{event.venue}</p>
                  <Link to={`/event/${event.id}`} className="btn btn-outline">Get Tickets</Link>
                </div>
              </div>
            ))}
          </div>
        </section>
        
        <section className="promo-section">
          <div className="promo-content">
            <div className="promo-text">
              <h2>Download Our App</h2>
              <p>Get exclusive deals and manage your bookings on the go!</p>
              <div className="app-buttons">
                <a href="#" className="app-button">Google Play</a>
                <a href="#" className="app-button">App Store</a>
              </div>
            </div>
            <div className="promo-image">
              <img src="https://images.pexels.com/photos/193004/pexels-photo-193004.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Mobile app" />
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}

export default Home
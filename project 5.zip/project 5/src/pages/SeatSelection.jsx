import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { fetchMovieById, fetchSeats } from '../utils/api'
import { useCart } from '../contexts/CartContext'
import '../styles/SeatSelection.css'

function SeatSelection() {
  const { id, showtime } = useParams()
  const navigate = useNavigate()
  const { addToCart } = useCart()
  
  const [movie, setMovie] = useState(null)
  const [selectedShowtime, setSelectedShowtime] = useState(null)
  const [seatLayout, setSeatLayout] = useState(null)
  const [selectedSeats, setSelectedSeats] = useState([])
  const [loading, setLoading] = useState(true)
  
  useEffect(() => {
    const loadData = async () => {
      try {

        const movieData = await fetchMovieById(id)
        setMovie(movieData)
        
  
        const show = movieData.showTimes.find(st => st.id === showtime)
        setSelectedShowtime(show)
        

        const seats = await fetchSeats(id, showtime)
        setSeatLayout(seats)
        
        setLoading(false)
      } catch (error) {
        console.error('Error loading data:', error)
        setLoading(false)
      }
    }
    
    loadData()
  }, [id, showtime])
  
  const toggleSeat = (seat) => {
    if (seat.status === 'booked') return
    
    setSelectedSeats(prevSeats => {
      const isSelected = prevSeats.some(s => s.id === seat.id)
      
      if (isSelected) {
        return prevSeats.filter(s => s.id !== seat.id)
      } else {
        return [...prevSeats, seat]
      }
    })
  }
  
  const isPriceType = (row, type) => {
    const firstSeat = seatLayout.rows.find(r => r.id === row)?.seats[0]
    return firstSeat && firstSeat.type === type
  }
  
  const proceedToCheckout = () => {
    if (selectedSeats.length === 0) {
      alert('Please select at least one seat to continue.')
      return
    }
    

    addToCart({
      movieId: movie.id,
      movieTitle: movie.title,
      posterUrl: movie.posterUrl,
      showtime: selectedShowtime.id,
      showtimeText: `${selectedShowtime.theater} - ${selectedShowtime.time}, ${new Date(selectedShowtime.date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}`,
      seats: selectedSeats,
      pricePerSeat: selectedSeats[0].price,
      totalPrice: selectedSeats.reduce((total, seat) => total + seat.price, 0)
    })
    
    navigate('/checkout')
  }
  
  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading seat map...</p>
      </div>
    )
  }
  
  if (!movie || !selectedShowtime || !seatLayout) {
    return (
      <div className="container">
        <div className="error-message">
          <h2>Error Loading Seats</h2>
          <p>We couldn't load the seat map for this showtime.</p>
          <button 
            onClick={() => navigate(`/movie/${id}`)}
            className="btn btn-primary"
          >
            Back to Movie
          </button>
        </div>
      </div>
    )
  }
  
  return (
    <div className="seat-selection-page">
      <div className="container">
        <div className="seat-selection-header">
          <h1>Select Your Seats</h1>
          <div className="movie-showtime-info">
            <div className="movie-thumb">
              <img src={movie.posterUrl} alt={movie.title} />
            </div>
            <div className="showtime-details">
              <h2>{movie.title}</h2>
              <p className="showtime-theater">{selectedShowtime.theater}</p>
              <p className="showtime-time">
                {selectedShowtime.time}, {new Date(selectedShowtime.date).toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </p>
            </div>
          </div>
        </div>
        
        <div className="seat-map-container">
          <div className="screen">
            <div className="screen-text">Screen</div>
          </div>
          
          <div className="seat-layout">
            {seatLayout.rows.map(row => (
              <div key={row.id} className="seat-row">
                <div className="row-label">{row.id}</div>
                <div className="seats">
                  {row.seats.map(seat => (
                    <div 
                      key={seat.id}
                      className={`seat ${seat.status} ${selectedSeats.some(s => s.id === seat.id) ? 'selected' : ''} ${seat.type}`}
                      onClick={() => toggleSeat(seat)}
                    >
                      <span>{seat.id.replace(row.id, '')}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
          
          <div className="seat-legend">
            {seatLayout.legend.map(item => (
              <div key={item.type} className="legend-item">
                <div className={`legend-indicator ${item.type}`}></div>
                <span>{item.label}</span>
              </div>
            ))}
            <div className="legend-item">
              <div className="legend-indicator regular"></div>
              <span>Regular ($12)</span>
            </div>
            <div className="legend-item">
              <div className="legend-indicator premium"></div>
              <span>Premium ($15)</span>
            </div>
            <div className="legend-item">
              <div className="legend-indicator vip"></div>
              <span>VIP ($20)</span>
            </div>
          </div>
        </div>
        
        <div className="booking-summary">
          <div className="summary-details">
            <h3>Booking Summary</h3>
            {selectedSeats.length > 0 ? (
              <>
                <div className="selected-seats-list">
                  <p><strong>Selected Seats:</strong> {selectedSeats.map(seat => seat.id).join(', ')}</p>
                </div>
                <div className="price-breakdown">
                  <div className="price-item">
                    <span>Tickets ({selectedSeats.length})</span>
                    <span>${selectedSeats.reduce((total, seat) => total + seat.price, 0).toFixed(2)}</span>
                  </div>
                  <div className="price-item">
                    <span>Booking Fee</span>
                    <span>$1.50</span>
                  </div>
                  <div className="price-total">
                    <span>Total</span>
                    <span>${(selectedSeats.reduce((total, seat) => total + seat.price, 0) + 1.50).toFixed(2)}</span>
                  </div>
                </div>
              </>
            ) : (
              <p className="no-seats-message">Please select your seats to continue</p>
            )}
            
            <div className="action-buttons">
              <button
                className="btn-back"
                onClick={() => navigate(`/movie/${id}`)}
              >
                Back
              </button>
              <button
                className="btn-proceed"
                onClick={proceedToCheckout}
                disabled={selectedSeats.length === 0}
              >
                Proceed to Checkout
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SeatSelection
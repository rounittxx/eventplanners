import { useState, useEffect } from 'react'
import { useSearchParams } from 'react-router-dom'
import MovieCard from '../components/MovieCard'
import { searchMovies, filterMovies } from '../utils/api'
import '../styles/MovieList.css'

function MovieList() {
  const [searchParams] = useSearchParams()
  const [movies, setMovies] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [activeFilters, setActiveFilters] = useState({
    genre: searchParams.get('genre') || '',
    language: '',
    date: ''
  })
  
  useEffect(() => {
    const loadMovies = async () => {
      setLoading(true)
      try {

        if (searchParams.get('genre')) {
          const filtered = await filterMovies({ genre: searchParams.get('genre') })
          setMovies(filtered)
        } else {
          const data = await searchMovies('')
          setMovies(data)
        }
      } catch (error) {
        console.error('Error loading movies:', error)
      } finally {
        setLoading(false)
      }
    }
    
    loadMovies()
  }, [searchParams])
  
  const handleSearch = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      const results = await searchMovies(searchTerm)
      setMovies(results)
    } catch (error) {
      console.error('Error searching movies:', error)
    } finally {
      setLoading(false)
    }
  }
  
  const handleFilter = async (filterType, value) => {
    const newFilters = { ...activeFilters, [filterType]: value }
    setActiveFilters(newFilters)
    
    setLoading(true)
    try {
      const results = await filterMovies(newFilters)
      setMovies(results)
    } catch (error) {
      console.error('Error filtering movies:', error)
    } finally {
      setLoading(false)
    }
  }
  
  const clearFilters = async () => {
    setActiveFilters({ genre: '', language: '', date: '' })
    setSearchTerm('')
    
    setLoading(true)
    try {
      const data = await searchMovies('')
      setMovies(data)
    } catch (error) {
      console.error('Error clearing filters:', error)
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <div className="movie-list-page">
      <div className="container">
        <section className="movie-list-header">
          <h1>Movies</h1>
          <p>Find and book tickets for the latest movies</p>
        </section>
        
        <section className="search-filter-section">
          <div className="search-bar">
            <form onSubmit={handleSearch}>
              <input
                type="text"
                placeholder="Search for movies, genres, or actors"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <button type="submit" className="search-btn">Search</button>
            </form>
          </div>
          
          <div className="filters">
            <div className="filter-group">
              <label>Genre</label>
              <select 
                value={activeFilters.genre}
                onChange={(e) => handleFilter('genre', e.target.value)}
              >
                <option value="">All Genres</option>
                <option value="action">Action</option>
                <option value="adventure">Adventure</option>
                <option value="comedy">Comedy</option>
                <option value="drama">Drama</option>
                <option value="sci-fi">Sci-Fi</option>
                <option value="romance">Romance</option>
                <option value="horror">Horror</option>
              </select>
            </div>
            
            <div className="filter-group">
              <label>Language</label>
              <select 
                value={activeFilters.language}
                onChange={(e) => handleFilter('language', e.target.value)}
              >
                <option value="">All Languages</option>
                <option value="english">English</option>
                <option value="spanish">Spanish</option>
                <option value="french">French</option>
                <option value="japanese">Japanese</option>
                <option value="korean">Korean</option>
              </select>
            </div>
            
            <div className="filter-group">
              <label>Release Date</label>
              <select 
                value={activeFilters.date}
                onChange={(e) => handleFilter('date', e.target.value)}
              >
                <option value="">Any Time</option>
                <option value="new">New Releases</option>
                <option value="upcoming">Coming Soon</option>
              </select>
            </div>
            
            <button 
              className="clear-filters"
              onClick={clearFilters}
            >
              Clear Filters
            </button>
          </div>
        </section>
        
        <section className="movies-grid-section">
          {loading ? (
            <div className="loading-container">
              <div className="loading-spinner"></div>
              <p>Loading movies...</p>
            </div>
          ) : movies.length > 0 ? (
            <div className="movies-grid">
              {movies.map(movie => (
                <div key={movie.id} className="movie-grid-item">
                  <MovieCard movie={movie} />
                </div>
              ))}
            </div>
          ) : (
            <div className="no-results">
              <h3>No movies found</h3>
              <p>Try adjusting your search or filters</p>
              <button 
                className="btn btn-primary"
                onClick={clearFilters}
              >
                Reset Filters
              </button>
            </div>
          )}
        </section>
      </div>
    </div>
  )
}

export default MovieList
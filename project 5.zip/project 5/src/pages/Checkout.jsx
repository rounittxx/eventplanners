import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useCart } from '../contexts/CartContext'
import { useAuth } from '../contexts/AuthContext'
import { bookSeats } from '../utils/api'
import '../styles/Checkout.css'

function Checkout() {
  const { cart, getTotal, clearCart } = useCart()
  const { currentUser } = useAuth()
  const navigate = useNavigate()
  
  const [paymentMethod, setPaymentMethod] = useState('card')
  const [cardNumber, setCardNumber] = useState('')
  const [cardName, setCardName] = useState('')
  const [cardExpiry, setCardExpiry] = useState('')
  const [cardCvv, setCardCvv] = useState('')
  const [loading, setLoading] = useState(false)
  const [errors, setErrors] = useState({})
  
  if (cart.length === 0) {
    return (
      <div className="container checkout-page">
        <div className="empty-cart">
          <h2>Your cart is empty</h2>
          <p>You haven't selected any movie tickets yet.</p>
          <button
            onClick={() => navigate('/movies')}
            className="btn btn-primary"
          >
            Browse Movies
          </button>
        </div>
      </div>
    )
  }
  
  const validateForm = () => {
    const newErrors = {}
    
    if (!cardNumber) newErrors.cardNumber = 'Card number is required'
    else if (!/^\d{16}$/.test(cardNumber.replace(/\s/g, ''))) 
      newErrors.cardNumber = 'Invalid card number'
    
    if (!cardName) newErrors.cardName = 'Name on card is required'
    
    if (!cardExpiry) newErrors.cardExpiry = 'Expiry date is required'
    else if (!/^\d{2}\/\d{2}$/.test(cardExpiry)) 
      newErrors.cardExpiry = 'Invalid expiry date format (MM/YY)'
    
    if (!cardCvv) newErrors.cardCvv = 'CVV is required'
    else if (!/^\d{3,4}$/.test(cardCvv)) 
      newErrors.cardCvv = 'Invalid CVV'
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }
  
  const formatCardNumber = (value) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '')
    const matches = v.match(/\d{4,16}/g)
    const match = (matches && matches[0]) || ''
    const parts = []
    
    for (let i = 0; i < match.length; i += 4) {
      parts.push(match.substring(i, i + 4))
    }
    
    if (parts.length) {
      return parts.join(' ')
    } else {
      return value
    }
  }
  
  const handleCardNumberChange = (e) => {
    const formattedValue = formatCardNumber(e.target.value)
    setCardNumber(formattedValue)
  }
  
  const formatExpiryDate = (value) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '')
    
    if (v.length > 2) {
      return `${v.substring(0, 2)}/${v.substring(2, 4)}`
    }
    
    return v
  }
  
  const handleExpiryChange = (e) => {
    const formattedValue = formatExpiryDate(e.target.value)
    setCardExpiry(formattedValue)
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!validateForm()) return
    
    setLoading(true)
    
    try {

      const bookingPromises = cart.map(item => 
        bookSeats({
          movieId: item.movieId,
          showtimeId: item.showtime,
          seats: item.seats.map(seat => seat.id),
          userId: currentUser?.id || 'guest',
          totalPrice: item.totalPrice
        })
      )
      
      await Promise.all(bookingPromises)
      

      clearCart()
      navigate('/confirmation')
    } catch (error) {
      console.error('Error processing payment:', error)
      setErrors({ submit: 'Failed to process payment. Please try again.' })
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <div className="container checkout-page">
      <div className="checkout-header">
        <h1>Checkout</h1>
        <p>Complete your purchase</p>
      </div>
      
      <div className="checkout-content">
        <div className="order-summary">
          <h2>Order Summary</h2>
          
          {cart.map((item, index) => (
            <div key={index} className="cart-item">
              <div className="cart-item-image">
                <img src={item.posterUrl} alt={item.movieTitle} />
              </div>
              <div className="cart-item-details">
                <h3>{item.movieTitle}</h3>
                <p className="showtime">{item.showtimeText}</p>
                <p className="seats">Seats: {item.seats.map(seat => seat.id).join(', ')}</p>
                <div className="cart-item-price">
                  <p>{item.seats.length} tickets</p>
                  <p>${item.totalPrice.toFixed(2)}</p>
                </div>
              </div>
            </div>
          ))}
          
          <div className="price-summary">
            <div className="price-row">
              <span>Subtotal</span>
              <span>${getTotal().toFixed(2)}</span>
            </div>
            <div className="price-row">
              <span>Booking Fee</span>
              <span>$1.50</span>
            </div>
            <div className="price-row total">
              <span>Total</span>
              <span>${(getTotal() + 1.50).toFixed(2)}</span>
            </div>
          </div>
        </div>
        
        <div className="payment-details">
          <h2>Payment Details</h2>
          
          <div className="payment-methods">
            <div 
              className={`payment-method ${paymentMethod === 'card' ? 'active' : ''}`}
              onClick={() => setPaymentMethod('card')}
            >
              <div className="payment-method-icon">💳</div>
              <span>Credit Card</span>
            </div>
            <div 
              className={`payment-method ${paymentMethod === 'paypal' ? 'active' : ''}`}
              onClick={() => setPaymentMethod('paypal')}
            >
              <div className="payment-method-icon">P</div>
              <span>PayPal</span>
            </div>
          </div>
          
          {errors.submit && (
            <div className="error-message">{errors.submit}</div>
          )}
          
          <form onSubmit={handleSubmit} className="payment-form">
            {paymentMethod === 'card' ? (
              <>
                <div className="form-group">
                  <label htmlFor="cardNumber">Card Number</label>
                  <input
                    type="text"
                    id="cardNumber"
                    value={cardNumber}
                    onChange={handleCardNumberChange}
                    placeholder="1234 5678 9012 3456"
                    maxLength="19"
                  />
                  {errors.cardNumber && (
                    <div className="field-error">{errors.cardNumber}</div>
                  )}
                </div>
                
                <div className="form-group">
                  <label htmlFor="cardName">Name on Card</label>
                  <input
                    type="text"
                    id="cardName"
                    value={cardName}
                    onChange={(e) => setCardName(e.target.value)}
                    placeholder="John Smith"
                  />
                  {errors.cardName && (
                    <div className="field-error">{errors.cardName}</div>
                  )}
                </div>
                
                <div className="form-row">
                  <div className="form-group half">
                    <label htmlFor="cardExpiry">Expiry Date</label>
                    <input
                      type="text"
                      id="cardExpiry"
                      value={cardExpiry}
                      onChange={handleExpiryChange}
                      placeholder="MM/YY"
                      maxLength="5"
                    />
                    {errors.cardExpiry && (
                      <div className="field-error">{errors.cardExpiry}</div>
                    )}
                  </div>
                  
                  <div className="form-group half">
                    <label htmlFor="cardCvv">CVV</label>
                    <input
                      type="text"
                      id="cardCvv"
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, ''))}
                      placeholder="123"
                      maxLength="4"
                    />
                    {errors.cardCvv && (
                      <div className="field-error">{errors.cardCvv}</div>
                    )}
                  </div>
                </div>
              </>
            ) : (
              <div className="paypal-instructions">
                <p>You will be redirected to PayPal to complete your payment.</p>
              </div>
            )}
            
            <div className="checkout-actions">
              <button
                type="button"
                className="btn-back"
                onClick={() => navigate(-1)}
              >
                Back
              </button>
              <button
                type="submit"
                className="btn-pay"
                disabled={loading}
              >
                {loading ? 'Processing...' : `Pay $${(getTotal() + 1.50).toFixed(2)}`}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

export default Checkout
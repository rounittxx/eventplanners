import { useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import '../styles/Confirmation.css'

function Confirmation() {
  const { currentUser } = useAuth()
  const navigate = useNavigate()

  const bookingId = 'BK' + Math.floor(Math.random() * 1000000).toString().padStart(6, '0')
  

  const bookingDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
  

  useEffect(() => {
    const handleBeforeUnload = (e) => {
      e.preventDefault()
      e.returnValue = ''
    }
    
    window.addEventListener('beforeunload', handleBeforeUnload)
    
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload)
    }
  }, [])
  
  return (
    <div className="confirmation-page">
      <div className="container">
        <div className="confirmation-box">
          <div className="confirmation-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
              <polyline points="22 4 12 14.01 9 11.01"></polyline>
            </svg>
          </div>
          
          <h1>Booking Confirmed!</h1>
          <p className="confirmation-message">
            Your tickets have been booked successfully. The confirmation has been sent to your email.
          </p>
          
          <div className="booking-details">
            <div className="booking-detail-item">
              <span className="detail-label">Booking ID:</span>
              <span className="detail-value">{bookingId}</span>
            </div>
            <div className="booking-detail-item">
              <span className="detail-label">Booking Date:</span>
              <span className="detail-value">{bookingDate}</span>
            </div>
            <div className="booking-detail-item">
              <span className="detail-label">Name:</span>
              <span className="detail-value">{currentUser ? currentUser.name : 'Guest User'}</span>
            </div>
            <div className="booking-detail-item">
              <span className="detail-label">Email:</span>
              <span className="detail-value">{currentUser ? currentUser.email : 'guest@example.com'}</span>
            </div>
            <div className="booking-detail-item">
              <span className="detail-label">Payment Method:</span>
              <span className="detail-value">Credit Card (**** 3456)</span>
            </div>
          </div>
          
          <div className="qr-code">
            <div className="qr-placeholder">QR Code</div>
            <p>Show this QR code at the venue to access your tickets</p>
          </div>
          
          <div className="confirmation-actions">
            <Link to="/" className="btn btn-primary">Back to Home</Link>
            
            {currentUser ? (
              <Link to="/bookings" className="btn btn-outline">View My Bookings</Link>
            ) : (
              <button 
                onClick={() => {
                  navigate('/')
                  
                  alert('Create an account to manage your bookings!')
                }}
                className="btn btn-outline"
              >
                Create Account
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Confirmation
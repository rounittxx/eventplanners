import { Link } from 'react-router-dom'
import '../styles/MovieCard.css'

function MovieCard({ movie }) {
  return (
    <div className="movie-card">
      <div className="movie-poster">
        <img src={movie.posterUrl} alt={movie.title} />
        <div className="movie-rating">
          <span>{movie.rating}</span>
        </div>
        <div className="movie-overlay">
          <Link to={`/movie/${movie.id}`} className="btn-view">View Details</Link>
        </div>
      </div>
      <div className="movie-info">
        <h3 className="movie-title">{movie.title}</h3>
        <div className="movie-meta">
          <span className="movie-genre">{movie.genre}</span>
          <span className="movie-duration">{movie.duration}</span>
        </div>
      </div>
    </div>
  )
}

export default MovieCard
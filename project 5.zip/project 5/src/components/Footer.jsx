import { Link } from 'react-router-dom'
import '../styles/Footer.css'

function Footer() {
  const currentYear = new Date().getFullYear()
  
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-section">
            <h3 className="footer-title">Event Planners</h3>
            <p className="footer-desc">
              Your one-stop destination for booking movie tickets and event passes.
              Find the best entertainment options in your city.
            </p>
            <div className="social-links">
              <a href="#" className="social-link">
                <i className="fab fa-facebook"></i>
              </a>
              <a href="#" className="social-link">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="social-link">
                <i className="fab fa-instagram"></i>
              </a>
            </div>
          </div>
          
          <div className="footer-section">
            <h4 className="footer-heading">Quick Links</h4>
            <ul className="footer-links">
              <li><Link to="/">Home</Link></li>
              <li><Link to="/movies">Movies</Link></li>
              <li><Link to="/events">Events</Link></li>
              <li><Link to="/offers">Offers</Link></li>
              <li><Link to="/gift-cards">Gift Cards</Link></li>
            </ul>
          </div>
          
          <div className="footer-section">
            <h4 className="footer-heading">Categories</h4>
            <ul className="footer-links">
              <li><Link to="/movies?genre=action">Action Movies</Link></li>
              <li><Link to="/movies?genre=comedy">Comedy Movies</Link></li>
              <li><Link to="/events?category=concerts">Concerts</Link></li>
              <li><Link to="/events?category=theater">Theater</Link></li>
              <li><Link to="/events?category=sports">Sports</Link></li>
            </ul>
          </div>
          
          <div className="footer-section">
            <h4 className="footer-heading">Help & Support</h4>
            <ul className="footer-links">
              <li><Link to="/faq">FAQs</Link></li>
              <li><Link to="/terms">Terms & Conditions</Link></li>
              <li><Link to="/privacy">Privacy Policy</Link></li>
              <li><Link to="/contact">Contact Us</Link></li>
              <li><Link to="/feedback">Feedback</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="footer-bottom">
          <p>© {currentYear} Event Planners. All rights reserved.</p>
          <p>Designed for educational purposes</p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
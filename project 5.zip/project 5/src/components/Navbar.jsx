import { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import '../styles/Navbar.css'

function Navbar({ toggleLoginModal }) {
  const { currentUser, logout } = useAuth()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const location = useLocation()

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setScrolled(true)
      } else {
        setScrolled(false)
      }
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {

    setIsMenuOpen(false)
  }, [location])

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className={`navbar ${scrolled ? 'scrolled' : ''}`}>
      <div className="navbar-container container">
        <Link to="/" className="logo">
          <span className="highlight">Event</span>Planners
        </Link>
        
        <div className="mobile-toggle" onClick={toggleMenu}>
          <span></span>
          <span></span>
          <span></span>
        </div>
        
        <nav className={`nav-links ${isMenuOpen ? 'open' : ''}`}>
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/movies">Movies</Link></li>
            <li><Link to="/events">Events</Link></li>
            <li className="dropdown">
              <span>Categories</span>
              <div className="dropdown-content">
                <Link to="/movies?genre=action">Action</Link>
                <Link to="/movies?genre=comedy">Comedy</Link>
                <Link to="/movies?genre=drama">Drama</Link>
                <Link to="/events?category=concerts">Concerts</Link>
                <Link to="/events?category=theater">Theater</Link>
              </div>
            </li>
          </ul>
        </nav>
        
        <div className="nav-auth">
          {currentUser ? (
            <div className="user-menu">
              <button className="user-btn">
                {currentUser.name.charAt(0)}
              </button>
              <div className="user-dropdown">
                <Link to="/profile">My Profile</Link>
                <Link to="/bookings">My Bookings</Link>
                <button onClick={logout} className="logout-btn">Logout</button>
              </div>
            </div>
          ) : (
            <button className="login-btn" onClick={toggleLoginModal}>Login</button>
          )}
        </div>
      </div>
    </header>
  )
}

export default Navbar
import { useState } from 'react'
import '../styles/LocationSelector.css'

function LocationSelector() {
  const [selectedLocation, setSelectedLocation] = useState('New York')
  const [isOpen, setIsOpen] = useState(false)
  
  const locations = [
    'New York',
    'Los Angeles',
    'Chicago',
    'Houston',
    'Phoenix',
    'Philadelphia',
    'San Antonio',
    'San Diego',
    'Dallas',
    'San Jose'
  ]
  
  const handleLocationChange = (location) => {
    setSelectedLocation(location)
    setIsOpen(false)
  }
  
  return (
    <div className="location-selector">
      <div className="location-icon">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
          <circle cx="12" cy="10" r="3"></circle>
        </svg>
      </div>
      
      <div className="location-dropdown">
        <div 
          className="selected-location" 
          onClick={() => setIsOpen(!isOpen)}
        >
          <span>{selectedLocation}</span>
          <svg className={`arrow ${isOpen ? 'open' : ''}`} xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="6 9 12 15 18 9"></polyline>
          </svg>
        </div>
        
        {isOpen && (
          <div className="location-options">
            {locations.map(location => (
              <div 
                key={location} 
                className={`location-option ${location === selectedLocation ? 'active' : ''}`}
                onClick={() => handleLocationChange(location)}
              >
                {location}
              </div>
            ))}
          </div>
        )}
      </div>
      
      <p className="location-message">
        Showing movies and events in <strong>{selectedLocation}</strong>
      </p>
    </div>
  )
}

export default LocationSelector
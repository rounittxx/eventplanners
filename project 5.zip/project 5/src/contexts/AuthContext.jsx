import { createContext, useContext, useState, useEffect } from 'react'

const AuthContext = createContext()

export function useAuth() {
  return useContext(AuthContext)
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null)
  const [loading, setLoading] = useState(true)
  
  
  useEffect(() => {
    const storedUser = localStorage.getItem('user')
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser))
    }
    setLoading(false)
  }, [])
  

  async function login(email, password) {

    return new Promise((resolve, reject) => {
      setTimeout(() => {
       
        if (email === 'user@example.com' && password === 'password') {
          const user = {
            id: '1',
            email: email,
            name: 'John Doe',
          }
          setCurrentUser(user)
          localStorage.setItem('user', JSON.stringify(user))
          resolve(user)
        } else {
          reject(new Error('Invalid email or password'))
        }
      }, 1000)
    })
  }
  

  async function signup(email, password, name) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
  
        const user = {
          id: '2',
          email: email,
          name: name,
        }
        setCurrentUser(user)
        localStorage.setItem('user', JSON.stringify(user))
        resolve(user)
      }, 1000)
    })
  }
  

  function logout() {
    setCurrentUser(null)
    localStorage.removeItem('user')
  }
  
  const value = {
    currentUser,
    login,
    signup,
    logout,
  }
  
  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  )
}
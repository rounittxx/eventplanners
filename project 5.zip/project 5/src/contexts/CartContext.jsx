import { createContext, useContext, useState, useEffect } from 'react'

const CartContext = createContext()

export function useCart() {
  return useContext(CartContext)
}

export function CartProvider({ children }) {
  const [cart, setCart] = useState([])
  const [loading, setLoading] = useState(true)
  

  useEffect(() => {
    const storedCart = localStorage.getItem('cart')
    if (storedCart) {
      setCart(JSON.parse(storedCart))
    }
    setLoading(false)
  }, [])
  

  useEffect(() => {
    if (!loading) {
      localStorage.setItem('cart', JSON.stringify(cart))
    }
  }, [cart, loading])
  

  const addToCart = (item) => {
    setCart(prevCart => {

      const exists = prevCart.findIndex(i => 
        i.movieId === item.movieId && i.showtime === item.showtime
      )
      
      if (exists >= 0) {
        const updatedCart = [...prevCart]
        updatedCart[exists] = item
        return updatedCart
      }
      

      return [...prevCart, item]
    })
  }

  const removeFromCart = (movieId, showtime) => {
    setCart(prevCart => prevCart.filter(
      item => !(item.movieId === movieId && item.showtime === showtime)
    ))
  }
  

  const clearCart = () => {
    setCart([])
  }

  const getTotal = () => {
    return cart.reduce((total, item) => {
      return total + (item.seats.length * item.pricePerSeat)
    }, 0)
  }
  
  const value = {
    cart,
    addToCart,
    removeFromCart,
    clearCart,
    getTotal,
  }
  
  return (
    <CartContext.Provider value={value}>
      {!loading && children}
    </CartContext.Provider>
  )
}
import { useState } from 'react'
import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Home from './pages/Home'
import MovieList from './pages/MovieList'
import MovieDetail from './pages/MovieDetail'
import SeatSelection from './pages/SeatSelection'
import Checkout from './pages/Checkout'
import Confirmation from './pages/Confirmation'
import NotFound from './pages/NotFound'
import LoginModal from './components/LoginModal'
import { AuthProvider } from './contexts/AuthContext'
import { CartProvider } from './contexts/CartContext'
import './styles/App.css'

function App() {
  const [showLoginModal, setShowLoginModal] = useState(false)

  const toggleLoginModal = () => {
    setShowLoginModal(!showLoginModal)
  }

  return (
    <AuthProvider>
      <CartProvider>
        <div className="app">
          <Navbar toggleLoginModal={toggleLoginModal} />
          <main className="main-content">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/movies" element={<MovieList />} />
              <Route path="/movie/:id" element={<MovieDetail />} />
              <Route path="/select-seats/:id/:showtime" element={<SeatSelection />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/confirmation" element={<Confirmation />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          <Footer />
          {showLoginModal && <LoginModal onClose={toggleLoginModal} />}
        </div>
      </CartProvider>
    </AuthProvider>
  )
}

export default App